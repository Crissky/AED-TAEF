import pickle, os, datetime

class Bibliotec:
    def __init__(self, DataBaseBooks, DataBaseUsers):
        self.__DataBaseBooks = DataBaseBooks
        self.__DataBaseUsers = DataBaseUsers

        self.__rootPath = os.getcwd()
        self.__superUser = 0

        self.loadDataBase()

    def signupUser (self, CPF, name, password=None):
        if(self.CPFVerify(CPF)):
            if(self.__superUser == 0):
                self.__DataBaseUsers.insert(CPF, {'name':name, 'books':[], 'refund':[], 'password':password, 'superUser':1})
                self.__superUser = 1
                return 'Admnistrador cadastrado com sucesso.'
            elif(self.__DataBaseUsers.insert(CPF, {'name':name, 'books':[], 'refund':[], 'password':password, 'superUser':0})):
                return 'Usuário cadastrado com sucesso.'
            else:
                return 'CPF de número %s já está cadastrado no sistema.'%(CPF)
        else:
            return 'CPF inválido.'

    def CPFVerify(self, CPF):
        return 1
        CPF = CPF.replace('.','')
        CPF = CPF.replace('-','')

        if(len(CPF) == 11):
            asum = 0
            multiplier = 10
            for x in range(len(CPF)-2):
                asum += int(CPF[x])*multiplier
                multiplier -= 1

            if (asum%11 < 2 and int(CPF[-2]) == 0) or (asum%11 >= 2 and int(CPF[-2]) == 11-(asum%11)):
                asum = 0
                multiplier = 11
                for x in range(len(CPF)-1):
                    asum += int(CPF[x])*multiplier
                    multiplier -= 1

                if(asum%11 < 2 and int(CPF[-1]) == 0) or (asum%11 >= 2 and int(CPF[-1]) == 11-(asum%11)):
                    return 1
        return 0    

    def reportUsers(self):
        alist = self.__DataBaseUsers.list()
        report = []
        report.append('Relatório do dia %d/%d/%d'%(datetime.date.today().day, datetime.date.today().month, datetime.date.today().year))
        for x in range(len(alist)):
            y = self.__DataBaseUsers.search(alist[x])
            books = 'Nenhum' if y.getData()['books']==[] else ', '.join([str(z) for z in y.getData()['books']])
            report.append('CPF: '+str(y.getKey())+'\n'+'Nome: '+y.getData()['name']+'\n'+'Livros emprestado: '+books)

        if('Reports' not in os.listdir()):
            os.mkdir('Reports') #Cria pasta

        os.chdir('Reports') #Muda o diretório
        arq = open('Report_Users.txt', 'w')
        arq.write('\n\n'.join(report))
        arq.close()
        self.rootPath()
        
                
    def login(self, login, password):
        user = self.__DataBaseUsers.search(CPF)
        
        if(user.getKey() == CPF and user.getData()['password'] == password):
            return 1
        return 0

    def superLogin(self, login, password):
        user = self.__DataBaseUsers.search(CPF)
        
        if(user.getKey() == CPF and user.getData()['password'] == password and user.getData()['superUser'] == 1):
            return 1
        return 0

    def requestBook(self, CPF, book):
        user = self.__DataBaseUsers.search(CPF)
        request = self.__DataBaseBooks.search(book)

        if(book in user.getData()['books']):
            return '%s já está com o uma cópia do livro %s emprestado.'%(str(user.getData()['name']), str(book))
        if(request.getKey() == book):
            if(request.getData()['numbers'] > 0):
                request.getData()['numbers'] -= 1
                request.getData()['users'].append(user)
                user.getData()['books'].append(request)
                user.getData()['refund'].append(datetime.date.fromordinal(datetime.date.today().toordinal()+7))
                return 'Livro reservado'
            else:
                return 'Livro indisponível.'
        return 'Livro não cadastrado.'
    
    def registerBook (self, bookName, ISBN=None, numbers=1):
        if(ISBN==None or self.ISBNVerify(ISBN)):
            if(self.__DataBaseBooks.insert(bookName, {'ISBN':ISBN, 'numbers':numbers, 'total':numbers, 'users':[]})):
                return 'Livro cadastrado com sucesso'#1
            else:
                book = self.__DataBaseBooks.search(bookName)
                book.getData()['numbers'] += numbers
                book.getData()['total'] += numbers
                return 'Livro adicionado com sucesso.'
                
        else:
            return 'ISBN incorreto.'
    
    def deleteBook (self, bookName):
        self.__DataBaseBooks.insert(bookName)
        
    def ISBNVerify(self, ISBN):
        ISBN = ISBN.replace('-','')
        if(len(ISBN) == 13):
            asum = 0
            for x in range(len(ISBN)-1):
                if(x%2 == 0):
                    asum += int(ISBN[x])*1
                else:
                    asum += int(ISBN[x])*3
            if((10-(asum%10)) == int(ISBN[-1])):
                return 1
        return 0

    def reportBooks(self):
        if('Reports' not in os.listdir()):
            os.mkdir('Reports') #Cria pasta

        alist = self.__DataBaseBooks.list()
        for x in range(len(alist)):
            alist[x] = alist[x]+' - Livros em estoque: %d/%d'%(int(self.__DataBaseBooks.search(alist[x]).getData()['numbers']),int(self.__DataBaseBooks.search(alist[x]).getData()['total']))
            
        os.chdir('Reports') #Muda o diretório
        arq = open('Report_Books.txt', 'w')
        today = 'Relatório do dia %d/%d/%d\n\n'%(datetime.date.today().day, datetime.date.today().month, datetime.date.today().year)
        arq.write(today+'\n'.join(alist))
        arq.close()
        self.rootPath()

        return str(self.__DataBaseBooks)
    
    def rootPath(self):
        os.chdir(self.__rootPath) #Retorna para o diretório raiz do programa.
        
    def saveDataBase(self):
        self.rootPath()
        if('DataBase' not in os.listdir()):
            os.mkdir('DataBase') #Cria pasta

        os.chdir('DataBase') #Muda o diretório

        archive = open('databooks.aed', 'wb')
        pickle.dump(self.__DataBaseBooks, archive)
        archive.close()

        archive = open('datausers.aed', 'wb')
        pickle.dump(self.__DataBaseUsers, archive)
        archive.close()

        self.rootPath()

    def loadDataBase(self):
        self.rootPath()
        if('DataBase' in os.listdir()):
            os.chdir('DataBase')
            try:
                self.__DataBaseBooks, self.__DataBaseUsers = pickle.load(open('databooks.aed', 'rb')), pickle.load(open('datausers.aed', 'rb'))
            except:
                self.rootPath()
                return 'Erro ao carregar banco de dados. Favor verificar a integridade dos arquivos.'
        self.rootPath()

    
        
        
if(__name__ == '__main__'):
    from New_RB_Tree import *
    from random import randint, choice
    limite = 10000
    bli = Bibliotec(RBTree(), RBTree())
    letras = []
    livros = []
    usuarios = []
    #bli.loadDatabase()

    for x in range(97,123):
        letras.append(chr(x))

    for x in range(limite):
        nome = ''
        for y in range(randint(5,15)):
            if(y%2 == 0):
                nome+= choice(letras)
            else:
                nome+= choice(['a','e','i','o','u'])
        livros.append(str(nome).capitalize())
        bli.registerBook(str(nome).capitalize(), None, randint(0, 50))

    #bli.reportBooks()

    for x in range(limite):
        nome = ''
        for y in range(randint(5,15)):
            if(y%2 == 0):
                nome+= choice(letras)
            elif(x%y == 1):
                nome += ' '
            else:
                nome+= choice(['a','e','i','o','u'])
        y = randint(0, limite**2)
        usuarios.append(str(y))
        bli.signupUser(str(y),nome.capitalize())

    for x in range(limite//2):
        bli.requestBook(choice(usuarios), choice(livros))

        
    bli.reportBooks()
    bli.reportUsers()
    bli.saveDataBase()
    #print(bli.CPFVerify(input('Insira o CPF: ')))
