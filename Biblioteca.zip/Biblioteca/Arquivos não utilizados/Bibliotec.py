import pickle, os#, datetime
from Authenticator import *
from datetime import datetime #Função datetime.now() e datetime.today() funcionam do memso jeito retornando data e hora, já o date.today() não só retorna a data.
#datetime trabalha com data e hora e a date somente com data, com relação a data, ambas são muito parecidas.

class Bibliotec:
    def __init__(self, DataBaseBooks, DataBaseUsers, maxBooks=3):
        self.__DataBaseBooks = DataBaseBooks
        self.__DataBaseUsers = DataBaseUsers

        self.__rootPath = os.getcwd()
        self.__superUser = 0
        self.__maxBooks = maxBooks
        self.__inviteBook = []

        self.loadDataBase()
        self.signupUser('07947643474', 'Edson', '0000')
        
    #Cadastro de usuários
    def signupUser (self, CPF, name, password='8888'):
        if(CPFVerify(CPF)):
            if(self.__superUser == 0):
                self.__DataBaseUsers.insert(CPF, {'name':name, 'books':[], 'refund':[], 'password':password, 'superUser':1})
                self.__superUser = 1
                #return 'Administrador cadastrado com sucesso.'
                return print('Administrador cadastrado com sucesso.')
                
            elif(self.__DataBaseUsers.insert(CPF, {'name':name, 'books':[], 'refund':[], 'password':password, 'superUser':0})):
                #return 'Usuário cadastrado com sucesso.'
                return print('Usuário cadastrado com sucesso.')
            else:
                #return 'CPF de número %s já está cadastrado no sistema.'%(CPF)
                return print('CPF de número %s já está cadastrado no sistema.'%(CPF))
        else:
            #return 'CPF inválido.'
            return print('CPF inválido.')

    #Cria arquivo .TXT com os dados dos usuários
    def reportUsers(self):
        self.rootPath()
        alist = self.__DataBaseUsers.list()
        report = []
        report.append('Relatório gerado às %d:%d do dia %d/%d/%d'%(datetime.now().hour, datetime.now().minute, datetime.now().day, datetime.now().month, datetime.now().year))
        for x in range(len(alist)):
            y = self.__DataBaseUsers.search(alist[x])
            books = 'Nenhum' if y.getData()['books']==[] else ', '.join(y.getData()['books'])
            report.append('CPF: '+str(y.getKey())+'\n'+'Nome: '+y.getData()['name']+'\n'+'Livros emprestado: '+books)

        if('Reports' not in os.listdir()):
            os.mkdir('Reports') #Cria pasta

        os.chdir('Reports') #Muda o diretório
        arq = open('Report_Users.txt', 'w')
        arq.write('\n\n'.join(report))
        arq.close()

        del alist, report
        self.rootPath()
        
    #Autenticação de login de usuário
    def login(self, login, password): 
        user = self.__DataBaseUsers.search(CPF)
        
        if(user.getKey() == CPF and user.getData()['password'] == password):
            return 1
        return 0

    #Autenticação de login de administrador
    def superLogin(self, login, password):
        user = self.__DataBaseUsers.search(CPF)
        
        if(user.getKey() == CPF and user.getData()['password'] == password and user.getData()['superUser'] == 1):
            return 1
        return 0

    #Solicitação de livro.
    def requestBook(self, CPF, book):
        user = self.__DataBaseUsers.search(CPF)
        if(user.getKey() == None):
            #return 'CPF não cadastrado.'
            return print('CPF não cadastrado.')
        
        request = self.__DataBaseBooks.search(book)
        if(request.getKey() == None):
            #return 'Livro não cadastrado.'
            return print('Livro não cadastrado.')

        self.__inviteBook.append([CPF, book])

    #Lista de solicitação de livros.
    def getRequestBook(self):
        return self.__inviteBook

    #Aprova solicitação de livros.
    def approveRequestBook(self, CPF, book):
        user = self.__DataBaseUsers.search(CPF)
        request = self.__DataBaseBooks.search(book)

        if(book in user.getData()['books']):
            #return '%s já está com o uma cópia do livro %s emprestado.'%(str(user.getData()['name']), str(book))
            return print('%s já está com o uma cópia do livro %s emprestado.'%(str(user.getData()['name']), str(book)))
        if(request.getKey() == book):
            if(request.getData()['numbers'] > 0):
                request.getData()['numbers'] -= 1
                request.getData()['users'].append(CPF)
                user.getData()['books'].append(book)
                user.getData()['refund'].append(datetime.fromordinal(datetime.now().toordinal()+7))
                #return 'Livro reservado'
                return print('Livro reservado')
            else:
                #return 'Livro indisponível.'
                return print('Livro indisponível.')
        #return 'Livro não cadastrado.'
        return print('Livro não cadastrado.')

    #Cadastro de livros.
    def registerBook (self, bookName, ISBN=None, numbers=1):
        if(ISBN==None or ISBNVerify(ISBN)):
            if(self.__DataBaseBooks.insert(bookName, {'ISBN':ISBN, 'numbers':numbers, 'total':numbers, 'users':[]})):
                #return 'Livro cadastrado com sucesso'#1
                return print('Livro cadastrado com sucesso')
            else:
                book = self.__DataBaseBooks.search(bookName)
                book.getData()['numbers'] += numbers
                book.getData()['total'] += numbers
                #return 'Livro adicionado com sucesso.'
                return print('Livro adicionado com sucesso.')
                
        else:
            #return 'ISBN incorreto.'
            return print('ISBN incorreto.')
    
    #Exclui livro do banco de dados.
    def deleteBook (self, bookName):
        if(self.__DataBaseBooks.delete(bookName)):
            #return 1
            return print('Livro %s excluído do banco de dados.'%(str(bookName)))
        #return 0
        return print('Livro não encontrado')
        
    #Cria arquivo .TXT com todos os livros no banco de dados.
    def reportBooks(self):
        self.rootPath()
        if('Reports' not in os.listdir()):
            os.mkdir('Reports') #Cria pasta

        alist = self.__DataBaseBooks.list()
        number = 1
        zeros = len(str(len(alist)))
        for x in range(len(alist)):
            alist[x] = str(number).rjust(zeros,'0')+' - '+alist[x]+' - Livros em estoque: %d/%d'%(int(self.__DataBaseBooks.search(alist[x]).getData()['numbers']),int(self.__DataBaseBooks.search(alist[x]).getData()['total']))
            number += 1
            
        os.chdir('Reports') #Muda o diretório
        arq = open('Report_Books.txt', 'w')
        today = 'Relatório gerado às %d:%d do dia %d/%d/%d\n\n'%(datetime.today().hour, datetime.today().minute, datetime.today().day, datetime.today().month, datetime.today().year)
        arq.write(today+'\n'.join(alist))
        arq.close()
        self.rootPath()

        del alist

    def refundBook(self, CPF, book):
        user = self.__DataBaseUsers.search(CPF)
        if(user.getKey() == None):
            #return 'CPF não cadastrado.'
            return print('CPF não cadastrado.')
        
        refund = self.__DataBaseBooks.search(book)
        if(refund.getKey() == None):
            #return 'Livro não cadastrado.'
            return print('Livro não cadastrado.')

        try:
            index = user.getData()['books'].index(book)
        except:
            #return 'Livro não está com %s'%(str(user.getData()['name']))
            return print('Livro não está com %s'%(str(user.getData()['name'])))
        
            
        del user.getData()['books'][index]
        refundday = user.getData()['refund'].pop(index).toordinal()
        today = datetime.today().toordinal()

        index = refund.getData()['users'].index(CPF)
        del refund.getData()['users'][index]
        refund.getData()['numbers'] += 1

        if(refundday-today < 0):
            #return 'Livro entregue com %d dia(s) de atraso.'%((refundday-today)*-1)
            return print('Livro entregue com %d dia(s) de atraso.'%((refundday-today)*-1))
        #return 1
        return print('Livro devolvido com sucesso.')
            
    #Retorna para o diretório raiz do programa.
    def rootPath(self):
        os.chdir(self.__rootPath)

    #Salva banco de dados.    
    def saveDataBase(self):
        self.rootPath()
        if('DataBase' not in os.listdir()):
            os.mkdir('DataBase') #Cria pasta

        os.chdir('DataBase') #Muda o diretório

        #archive = open('databooks.aed', 'wb')
        pickle.dump(self.__DataBaseBooks, open('databooks.aed', 'wb'))
        #pickle.dump(self.__DataBaseBooks, archive)
        #archive.close()

        #archive = open('datausers.aed', 'wb')
        pickle.dump(self.__DataBaseUsers, open('datausers.aed', 'wb'))
        #pickle.dump(self.__DataBaseUsers, archive)
        #archive.close()

        pickle.dump(self.__superUser, open('superuser.aed', 'wb'))
        pickle.dump(self.__maxBooks, open('maxbooks.aed', 'wb'))
        

        self.rootPath()

    #Carrega banco de dados.
    def loadDataBase(self):
        self.rootPath()
        if('DataBase' in os.listdir()):
            os.chdir('DataBase')
            try:
                self.__DataBaseBooks, self.__DataBaseUsers, self.__superUser, self.__maxBooks = pickle.load(open('databooks.aed', 'rb')), pickle.load(open('datausers.aed', 'rb')), pickle.load(open('superuser.aed', 'rb')), pickle.load(open('maxbooks.aed', 'rb'))
            except:
                self.rootPath()
                return print('Erro ao carregar banco de dados. Favor verificar a integridade dos arquivos.')
        self.rootPath()


if(__name__ == '__main__'):
    from New_RB_Tree import *
    from random import randint, choice
    limite = 100
    bli = Bibliotec(RBTree(), RBTree())
    letras = []
    livros = []
    usuarios = []
    devolucao = [None]*(limite//2)
    #bli.loadDatabase()

    for x in range(97,123):
        letras.append(chr(x))

    for x in range(limite):#Registrando livros
        nome = ''
        for y in range(randint(5,15)):
            if(y%2 == 0):
                nome+= choice(letras)
            else:
                nome+= choice(['a','e','i','o','u'])
        livros.append(str(nome).capitalize())
        bli.registerBook(str(nome).capitalize(), ISBNRandom(), randint(1, 50))

    #bli.reportBooks()

    for x in range(limite):#Cadastrando usuários
        nome = ''
        for y in range(randint(5,15)):
            if(y%2 == 0):
                nome+= choice(letras)
            elif(x%y == 1):
                nome += ' '
            else:
                nome+= choice(['a','e','i','o','u'])
        y = CPFRandom()
        usuarios.append(str(y))
        bli.signupUser(str(y),nome.capitalize())

    for x in range(limite//2): #Usuário pedindo livros.
        devolucao[x] = [choice(usuarios),choice(livros)]
        bli.approveRequestBook(devolucao[x][0], devolucao[x][1])

    for x in devolucao[:len(devolucao)//2]: #Devolvendo livro
        #print(x)
        bli.refundBook(x[0], x[1])

        
    bli.reportBooks()
    bli.reportUsers()
    bli.saveDataBase()
    #print(CPFVerify(input('Insira o CPF: ')))
