#arq = open('2.in','r')
#start = arq.readline().split('-')
start = input().split('-')
lista = [x.split() for x in start]
livros, pilhas = int(lista[0][0]), int(lista[0][1]); lista.pop(0)
esquerda, direita = 0,0

for x in range(len(lista)):
    if('1' in lista[x]):
        indiceL = x

indiceP = lista[indiceL].index('1')
    
if(indiceL > 0):
    esquerda = len(lista[indiceL-1])-indiceP
    
if(indiceL < len(lista)-1):
    direita = len(lista[indiceL+1])-indiceP

if(len(lista[indiceL])-1 != indiceP):
    acima = len(lista[indiceL][indiceP+1:])
else:
    acima = 0

if(indiceL == 0):
    print(acima+direita)
elif(indiceL == len(lista)-1):
    print(acima+esquerda)
else:
    if(direita >= esquerda):
            print(acima+esquerda)
    else:
        print(acima+direita)
