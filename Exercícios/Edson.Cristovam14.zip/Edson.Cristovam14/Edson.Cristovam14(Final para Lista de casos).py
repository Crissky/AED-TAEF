def contadorDeLivrosBACACA(start):
    start = start.split('-')
    lista = [x.split() for x in start]; lista.pop(0)
    
    for x in range(len(lista)):
        if('1' in lista[x]):
            indiceL = x

    indiceP = lista[indiceL].index('1')
        
    esquerda = len(lista[indiceL-1])-indiceP if indiceL > 0 else 0
    direita = len(lista[indiceL+1])-indiceP if indiceL < len(lista)-1 else 0
        

    acima = len(lista[indiceL][indiceP+1:]) if len(lista[indiceL])-1 != indiceP else 0
        
    
    if(indiceL == 0):
        print(acima+direita)
    elif(indiceL == len(lista)-1):
        print(acima+esquerda)
    else:
        print(acima+esquerda) if direita >= esquerda else acima+direita

#arq = open('1.in.txt','r')
#entrada = arq.readline()

#while entrada != '':
#    contadorDeLivrosBACACA(entrada)
#    entrada = arq.readline()

contadorDeLivrosBACACA(input())
